package com.javacodegeeks.controllers;

import java.security.Principal;

import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping("/chat")
public class ChatService {
	
	
	@GetMapping("/login2")
	public String chatService(Principal principal) {
		OAuth2Authentication oa = (OAuth2Authentication) principal;
		String temp = "Welcome called ( /chat/login)--->" + principal;
		System.out.println(temp);
		
		if(oa.getUserAuthentication().isAuthenticated()) {
			 //return "securedPage";
			 return "<H1>FSV CHAT PAGE</H1><br/><br/>Welcome to chat service Dear " + oa.getOAuth2Request().getClientId() + " to Spring Security Demo App for FSV" + "\n<H1>" + principal
						+ "</H1>";
		 }
		 else {
			 return "You are not yet authenticated <br/><a href=\"securedPage\">Login1 with LocalAuthServer</a>  ";
			 //return "Welcome "+principal.getName()+" to Spring Security <b>Chat</b> App for FSV"
			  //+"<br/><H1>"+principal+"</H1>";
		 }
		
		

	}
}
