package com.javacodegeeks.controllers;

import java.security.Principal;

import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping("/user")
public class UserController {
	
	
	@GetMapping("/securedPage")
	public String securedPage(Model model, Principal principal) {
		OAuth2Authentication oa = (OAuth2Authentication) principal;
		
		
		 if(oa !=null && oa.getUserAuthentication().isAuthenticated()) {
			 System.err.println(oa.getCredentials()); 
			 System.err.println(oa.getName());
			 System.err.println(oa.getPrincipal());
			 System.err.println(oa.getOAuth2Request().getClientId());
			 
			 return "<H1>FSV USER DETAIL PAGE</H1><br/><br/>Welcome "+oa.getPrincipal()+" You are seeing a securedPage. Because you are already authenticated."+"<br/>Your Authentication details are:<br/>"+
					 "<br/>Credentials:"+oa.getCredentials()
					 +"<br/>Name:"+oa.getName()
					 +"<br/>Principal:"+oa.getPrincipal().toString()
					 +"<br/>OAuth2RequestDetail:"+oa.getOAuth2Request().getClientId();	 
		 }
		 else {
			 return "You are not authenticated";
		 }
		
	}

	@GetMapping("/user/login1")
	public String welcomeUser(Principal principal) {
	   String temp="Welcome called ( /login)--->"+principal; 
	  System.out.println(temp); 
	  return "Welcome "+principal.getName()+" to Spring Security Demo App for FSV"
	  +"\n<H1>"+principal+"</H1>";
	  
	  }

	@PostMapping("/login1") 
	public String welcomePUser(Principal principal) {
	  String temp="Welcome called ( /login)--->"+principal;
	  System.out.println(temp); 
	  return "Welcome "+principal.getName()+" to Spring Security Demo App for FSV"
	  +"\n<H1>"+principal+"</H1>";
	  
	  }
	@GetMapping("/unauthenticated")
	public String errorUser(Principal principal) {
		String temp = "Welcome error called ( /login)--->" + principal;
		System.out.println(temp);
		return "Error for User " + principal.getName() + " in login Spring Security Demo App for FSV" + "\n<H1>" + principal
				+ "</H1>";

	}
}
