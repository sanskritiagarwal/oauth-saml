package com.javacodegeeks;

import java.security.Principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@SpringBootApplication
@Configuration
@EnableOAuth2Sso
@Controller
@EnableOAuth2Client
public class App extends WebSecurityConfigurerAdapter{

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
	
	@Override
    protected void configure(HttpSecurity http) throws Exception 
    {
        http.csrf().disable()
            .antMatcher("/**").authorizeRequests()
            .antMatchers("/", "/user/*","/chat/*","/index.html").permitAll()
            .anyRequest().authenticated();

    }

	@RequestMapping("/login")
	public String welcomeUser(Principal principal) {
		String temp = "Welcome get called ( /login)--->" + principal;
		System.out.println(temp);
		return "Welcome  to Spring Security Demo App for FSV" + "\n<H1>" + principal
				+ "</H1>";

	}

	@RequestMapping("/")
	public String defaultPage() {
		
		//return "Welcome "+" to Spring Security Demo App"+ "<br/><a href=\"securedPage\">Login with Local Auth Server</a>";
		return "index";
	}

	

}
