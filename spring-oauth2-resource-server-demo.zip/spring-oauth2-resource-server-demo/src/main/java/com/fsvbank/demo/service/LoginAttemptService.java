package com.fsvbank.demo.service;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.springframework.cglib.core.internal.LoadingCache;
import org.springframework.stereotype.Service;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;

@Service
public class LoginAttemptService {
 
    private final int MAX_ATTEMPT = 10;
    private LoadingCache<String, Integer,Integer> attemptsCache;
 
    @SuppressWarnings("unchecked")
	public LoginAttemptService() {
        super();
        attemptsCache = (LoadingCache<String, Integer, Integer>) CacheBuilder.newBuilder().
          expireAfterWrite(1, TimeUnit.DAYS).build(new CacheLoader<String, Integer>() {
            public Integer load(String key) {
                return 0;
            }
        });
    }
 
    public void loginSucceeded(String key) {
      //  attemptsCache.invalidate(key);
    }
 
    public void loginFailed(String key) throws ExecutionException {
        int attempts = 0;
        attempts = attemptsCache.get(key);
        attempts++;
        //attemptsCache.put(key, new Integer(attempts),new Integer(0));
    }
 
    public boolean isBlocked(String key) throws ExecutionException {
        return attemptsCache.get(key) >= MAX_ATTEMPT;
    }
}