package com.fsvbank.demo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.fsvbank.demo.dao.UserRepository;
import com.fsvbank.demo.resource.UserProfile;

@Service
@Transactional
public class CustomUserDetailService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	//@Autowired
	//private RoleRepository roleRepository;

	@Autowired
	private LoginAttemptService loginAttemptService;

	@Autowired
	private HttpServletRequest request;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		UserProfile user = userRepository.findByName(username);
		String ip = getClientIP();
		
		try 
		{
			if (loginAttemptService.isBlocked(ip)) {
				throw new RuntimeException("blocked");
			}
			if (user == null) {
			//	return new User("admin", "admin", true, true, true, true,
				//		getAuthorities(Arrays.asList(roleRepository.findByName("ROLE_USER"))));
			}

			if (user != null && user.isAccountNonLocked()) {
				return user;
			} else {
				return user;
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private String getClientIP() {
		String xfHeader = request.getHeader("X-Forwarded-For");
		if (xfHeader == null) {
			return request.getRemoteAddr();
		}
		return xfHeader.split(",")[0];
	}

	public UserProfile fetchUserProfile(String username) {
		UserProfile user = userRepository.findByName(username);
		if (user == null) {
			throw new UsernameNotFoundException(username);
		}
		System.err.println("Found---" + user);
		return user;
	}

	public Iterable<UserProfile> fetchAllUserProfile(String username) {
		return userRepository.findAll();
	}

	public UserDetails loadUserById(int id) {

		Optional<UserProfile> user = userRepository.findById((long) id);
		user.orElse(new UserProfile());
		if (user.get() == null) {
			throw new UsernameNotFoundException(String.valueOf(id));
		}
		return new MyUserPrincipal(user.get());
	}

	public List<UserProfile> save2User(String clientId) {
		UserProfile user1 = new UserProfile();
		UserProfile user2 = new UserProfile();
		UserProfile user3 = new UserProfile();
		String paswd = "1234";
		String role = "USER";
		List<UserProfile> list = new ArrayList<>();
		try {

			// USER 2
			user2.setName("FsvAdmmin");
			user2.setPaswd(paswd);
			user2.setRole(role);
			user2.setEmail("fsvadmin@fsvbank.com");
			user2.setClientId(clientId);
			user2.setRedirectUrls("http://maps.googleapis.com/maps/api/geocode/json");
			list.add(user2);

			// USER 1
			user1.setName("Sanskriti");
			user1.setPaswd(paswd);
			user1.setRole(role);
			user1.setEmail("sanskriti@fsvbank.com");
			user1.setClientId(clientId);
			user2.setRedirectUrls("https://graph.facebook.com/youtube");
			list.add(user1);

			// USER 3
			user3 = new UserProfile();
			user3.setPaswd(paswd);
			user3.setRole(role);
			user3.setName("GreenApple");
			user3.setEmail("greenapple@fsvbank.com");
			user3.setClientId(clientId);
			user3.setRedirectUrls("http://maps.googleapis.com/maps/api/geocode/json");
			list.add(user3);

			userRepository.saveAll(list);

			System.err.println("Total entities present: " + userRepository.count());

			Iterable<UserProfile> ls = userRepository.findAll();
			Iterator<UserProfile> ii = ls.iterator();
			while (ii.hasNext()) {
				System.err.println(ii.next().toString());
			}
		} catch (Exception ue) {
			ue.printStackTrace();
		}
		return list;

	}

}

class MyUserPrincipal implements UserDetails {
	private UserProfile user;

	public MyUserPrincipal(UserProfile user) {
		this.user = user;
	}
	// ...

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}
}