package com.fsvbank.demo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Repository;

import com.fsvbank.demo.resource.UserProfile;

@Repository
public interface UserRepository extends CrudRepository<UserProfile, Long> {

	UserProfile findByName(String username);
	 
    
}