package com.fsvbank.demo.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsvbank.demo.service.CustomUserDetailService;

@RestController
public class RestResource {
	@Autowired
	CustomUserDetailService customUserDetailService;

	@GetMapping("/api/users/me")
	public ResponseEntity<UserProfile> profile() {
		// Build some dummy data to return for testing
		String principalStr = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserDetails user;
		if (principalStr.equalsIgnoreCase("anonymousUser")) {
			System.err.println(" recieved -" + principalStr);
			UserProfile profile = customUserDetailService.fetchUserProfile("Admin");
			System.err.println("USer Profile fetched:--------"+profile);
			return ResponseEntity.ok(profile);
		}  
		else {
			user = customUserDetailService.loadUserByUsername(principalStr);
			System.err.println("User Found-" + user.toString());
			if (user.isAccountNonExpired() && user.isAccountNonLocked() && user.isEnabled()) {
				// profile.setClientId(oa.getOAuth2Request().getClientId());
				UserProfile profile = (UserProfile) user;
				profile.setName(principalStr);
				profile.setEmail(principalStr + "@fsvbank.com");
				System.err.println("Profile made: " + profile.toString());
				return ResponseEntity.ok(profile);
			} else {
				UserProfile profile = customUserDetailService.fetchUserProfile(principalStr);
				return ResponseEntity.ok(profile);
			}
		}
		

	}
}
